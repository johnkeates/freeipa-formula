#
# Copyright (C) 2015  FreeIPA Contributors see COPYING for license
#

'''
Module containing platform-specific functionality for every platform.
'''

NAME = "debian"

# FIXME: too much cyclic dependencies
# from debian import paths, tasks, services
